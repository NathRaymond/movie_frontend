<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


Auth::routes();
Route::get('/', [App\Http\Controllers\MovieController::class, 'index'])->name('home');
Route::get('/movie', [App\Http\Controllers\MovieController::class, 'movie_index'])->name('movie_home');
Route::post('/store-movie', [App\Http\Controllers\MovieController::class, 'store_movie'])->name('store-movie');
Route::get('/getmovie_detail', [App\Http\Controllers\MovieController::class, 'getmovieInfor'])->name('get_movie');
Route::post('/update-movie', [App\Http\Controllers\MovieController::class, 'update_movie'])->name('updatemovie');
Route::get('/delete_movies', [App\Http\Controllers\MovieController::class, 'destroy_movie'])->name('delete_movies');
